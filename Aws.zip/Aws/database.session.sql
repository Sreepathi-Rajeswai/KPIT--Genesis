-- create database ride2;

-- use ride;

-- CREATE TABLE details
-- ( 
-- ride nvarchar(20),
-- driver varchar(20),
-- customer varchar(29),
-- passanger int);

-- INSERT into details (ride,driver,customer,passanger)
-- VALUES (78,'kamal','shanti',1);

-- INSERT into details (ride,driver,customer,passanger)
-- VALUES (79,'kamala','shant',2);


SELECT* FROM details