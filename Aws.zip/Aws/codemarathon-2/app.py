import mysql.connector
 
def insert_data(connection):
    cursor = connection.cursor()
 
    rides = [
        (4, 'shrav', 'kamal', 4),
        (5, 'komala', 'rajeswari', 5),
        (6, 'kavya', 'pravalika', 6)
    ]
 
    for ride in rides:
        cursor.execute("INSERT INTO details (ride, driver, customer, passanger) VALUES (%s, %s, %s, %s)",ride)
 
    connection.commit()
    print("Data inserted successfully")
 
def main():
    connection = None
    try:
        connection = mysql.connector.connect(
        host = 'pravalikadb.c0ofughktlpd.us-east-1.rds.amazonaws.com',
        user = 'admin',
        password = 'Password!123',
        database = 'ride'
 
    )
        print("Connected to the database")
    except Exception as e:
        print("Error while connecting to database")
    if connection is not None:
        insert_data(connection)
        connection.close()
    return connection
 
if __name__ == "__main__":
    main()
