-- create database r;

-- use r;

-- CREATE TABLE utilit
-- ( 
-- month nvarchar(20),
-- unitsused int,
-- payableamount int);

-- INSERT into utilit (month, unitsused, payableamount)
-- VALUES ('jan',120,870);

-- INSERT into utilit (month,unitsused,payableamount)
-- VALUES ('feb',87,730);

-- INSERT into utilit (month,unitsused,payableamount)
-- VALUES ('mar',92,810);



SELECT* FROM utilit