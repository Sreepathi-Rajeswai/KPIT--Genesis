
-- create schema rds;
-- use rds;

-- CREATE TABLE employee
-- ( empid int primary key auto_increment,
-- firstname nvarchar(20),
-- lastname nvarchar(30));

-- INSERT into employee (firstname, lastname)
-- VALUES ('raji','sree');

-- INSERT into employee (firstname, lastname)
-- VALUES ('Micky','Mouse');
select * from employee