#create a python s3 bucket
import boto3
s3 = boto3.resource('s3')
for bucket in s3.buckets.all():
    print(bucket.name)
response=s3.create_bucket(
    Bucket='abcd36463',
    createBucketConfiguration=
    {'LocationConstraint':'us-east-1'})
print(response)
#perform CRUD on bucket objects
client=boto3.client('s3')
client.put_object(Bucket='abcd36463',Key='file101.txt',Body=b'Hello World')

#list Existing file in s3
# Retrieve the list of existing buckets
# s3 = boto3.client('s3')
# response = s3.list_buckets()

# Output the bucket names
# print('Existing buckets:')
# for bucket in response['Buckets']:
#     print(f'  {bucket["Name"]}')

#upload a file to the s3
# s3.upload_file(
#     'FILE_NAME', 'BUCKET_NAME', 'OBJECT_NAME',
#     Callback=ProgressPercentage('FILE_NAME')
# )

#transfer a file
# import boto3
# from boto3.s3.transfer import TransferConfig

# Set the desired multipart threshold value (5GB)
# GB = 1024 ** 3
# config = TransferConfig(multipart_threshold=5*GB)

# Perform the transfer
# s3 = boto3.client('s3')
# s3.upload_file('FILE_NAME', 'BUCKET_NAME', 'OBJECT_NAME', Config=config)