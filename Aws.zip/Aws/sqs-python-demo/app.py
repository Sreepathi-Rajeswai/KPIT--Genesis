#SQS creation
import boto3
queueUrl='https://sqs.ap-northeast-1.amazonaws.com/106129732153/orders'
sqs=boto3.client('sqs',region_name='ap-northeast-1')
sqs.send_message(QueueUrl=queueUrl,
                 MessageBody=('Hello me'))
response = sqs.receive_message(QueueUrl=queueUrl)
#response=sqs.receive_message(QueueUrl='https://sqs.ap-northeast-1.amazonaws.com/106129732153/orders')
#print(response)
for message in response['Messages']:
    print(message['Body'])
