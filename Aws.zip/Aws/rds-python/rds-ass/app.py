# import mysql.connector
# import boto3

# host = "bills.czos4uiy6sky.ap-southeast-1.rds.amazonaws.com"
# user = "admin"
# password = "Password!123"
# database = "r" 

# #my table is created at the name of rds if we use our database='rds' and table as employee not employees so we must change the select*from employee

# try:
#     connection = mysql.connector.connect(
#         host=host,
#         user=user,
#         password=password,
#         database=database
#     )
#     if connection.is_connected():
#         print("Connected to the database")

#         # Create a cursor
#         cursor = connection.cursor()

#         # Execute SQL queries
#         cursor.execute("SELECT payableamount,month FROM utilit")
#         rows = cursor.fetchall()

#         # Process the result
#         for row in rows:
#             print(row)

# except mysql.connector.Error as err:
#     print(f"Error: {err}")

# # finally:
# #     # Close the cursor and connection
# #     if 'cursor' in locals():
# #         cursor.close()
# #     if 'connection' in locals() and connection.is_connected():
# #         connection.close()
# #         print("Connection closed")


# client = boto3.client('sns',region_name='us-east-1')
# resp1 = client.create_topic(Name="bill-alerts-rajeswari")
# arn = resp1['TopicArn']
# print ("Created a new topic "+arn) 
# resp2 = client.subscribe(TopicArn=arn, Protocol='email', Endpoint='sreepathirajeswari85@gmail.com')
# print ("Publish a news ")
# #confirm the subscription through email message
# for i in range(3):
#     response=client.publish(TopicArn=arn,
#                 Subject="Monthly payment bills",
#                   Message="Hi,You bill for month <jan,feb,mar> is due. Please pay Rs <870,730,810> in 15 days")
#     print(response)



import boto3
import mysql.connector
from datetime import datetime
 
# AWS configuration
sns_topic_arn = "arn:aws:sns:ap-southeast-1:106129732153:bill-alerts-rajeswari"
 
# RDS configuration
rds_host = "bills.czos4uiy6sky.ap-southeast-1.rds.amazonaws.com"
rds_user = "admin"
rds_password = "Password!123"
rds_db_name = "r"
 
def send_bill_alert(subscriber, month, amount):
    message = f"Hi,\n\nYour bill for the month {month} is due. Please pay Rs {amount} in 15 days."
 
    # Print message to console (replace this with actual email sending code)
    print(f"Sending bill alert to {subscriber}: {message}")
 
def fetch_bills_data():
    connection = None  # Initialize the connection variable
 
    try:
        # Connect to RDS MySQL
        connection = mysql.connector.connect(
            host=rds_host,
            user=rds_user,
            password=rds_password,
            database=rds_db_name
        )
 
        if connection.is_connected():
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM utilit")
            result = cursor.fetchall()
            return result
 
    except Exception as e:
        print(f"Error connecting to RDS: {e}")
 
    finally:
        if connection and connection.is_connected():
            connection.close()
 
def get_subscribers_from_sns(topic_arn):
    sns_client = boto3.client('sns')
    response = sns_client.list_subscriptions_by_topic(TopicArn=topic_arn)
    subscribers = [subscription['Endpoint'] for subscription in response['Subscriptions']]
    return subscribers
 
def main():
    # Fetch subscribers from SNS topic
    sns_client = boto3.client('sns')
    subscribers = get_subscribers_from_sns(sns_topic_arn)
 
    # Fetch bills data from RDS
    bills_data = fetch_bills_data()
 
    if not bills_data:
        print("No data fetched from RDS. Exiting.")
        return
 
    # Iterate through bills data and send alerts
    for bill in bills_data:
        month = bill["month"]
        amount = bill["payableamount"]
 
        # Publish to SNS topic
        sns_client.publish(
            TopicArn=sns_topic_arn,
            Subject=f"Bill Alert: Payment Due for {month}",
            Message=f"Hi,\n\nYour bill for the month {month} is due. Please pay Rs {amount} in 15 days."
        )
 
        # Send emails to subscribers
        for subscriber in subscribers:
            send_bill_alert(subscriber, month, amount)
 
if __name__ == "__main__":
    main()
 