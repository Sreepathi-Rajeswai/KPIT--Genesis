//javascipt style of coding
//fun fun(username){}
function fun(username){
    console.log("Welcome" +username+ "to typescript")
}
fun("Rajeswari");
fun(1000);