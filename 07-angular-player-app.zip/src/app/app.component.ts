import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  players: any[] = [
    { playerId: 10101, playerName: 'MS Dhoni', playerAge: 40, status: 'inactive' },
    { playerId: 21100, playerName: 'Virat Kohali', playerAge: 38, status: 'active' },
    { playerId: 21356, playerName: 'Rohit Sharma', playerAge: 38, status: 'active' },
    { playerId: 11111, playerName: 'Sachin Tendulkar', playerAge: 50, status: 'inactive' }
  ]

  addPlayer(player: any) {
    this.players.push(player);
  }
  deletePlayer(player: any) {
    this.players = this.players.filter(p => p.playerId !== player.playerId);
  }

}











