import { Component, Output, EventEmitter } from '@angular/core';
// import { EventEmitter } from 'stream';

@Component({
  selector: 'app-add-player',
  templateUrl: './add-player.component.html',
  styleUrl: './add-player.component.css'
})
export class AddPlayerComponent {
  player: any = {}
  id = ''
  name = ''
  age = ''

  @Output() addPlayer = new EventEmitter();

  addPlayerHandler() {
    this.player.playerId = this.id;
    this.player.playerName = this.name;
    this.player.playerAge = this.age;
    //alert(JSON.stringify(this.player))
    this.addPlayer.emit(this.player);
    this.id = ''
    this.name = ''
    this.age = ''
  }
}
