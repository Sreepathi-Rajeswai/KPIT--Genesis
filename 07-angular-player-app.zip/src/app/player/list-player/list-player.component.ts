import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-list-player',
  templateUrl: './list-player.component.html',
  styleUrl: './list-player.component.css'
})
export class ListPlayerComponent {
  @Input() player: any = {};
  @Output() deletePlayer = new EventEmitter();

  deletePlayerHandler(p: any) {
    this.deletePlayer.emit(p);
  }

  getBackgroundColor() {
    if (Math.random() > 0.5) {
      return 'yellow';
    } else {
      return 'white'
    }
  }
  getActiveStatus() {
    if (this.player.status === 'active') {
      return false;
    } else {
      return true;
    }
  }
}
