import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListPlayerComponent } from './list-player/list-player.component';
import { AddPlayerComponent } from './add-player/add-player.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    ListPlayerComponent,
    AddPlayerComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [ListPlayerComponent, AddPlayerComponent]
})
export class PlayerModule { }
